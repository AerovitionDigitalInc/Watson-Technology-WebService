# Dialog
The [Dialog service][dialog] was deprecated on August 15, 2016, existing instances of the service will continue to function until August 9, 2017. Users of the Dialog service should migrate their applications to use the Conversation service. See the [migration documentation][dialog_migration] to learn how to migrate your dialogs to the [Conversation service][conversation].

[dialog]: http://www.ibm.com/watson/developercloud/doc/dialog/
[dialog_migration]: https://www.ibm.com/watson/developercloud/doc/conversation/migration.shtml
[conversation]: https://www.ibm.com/watson/developercloud/doc/conversation/