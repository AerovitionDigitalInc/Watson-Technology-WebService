/*
 * Copyright 2017 IBM Corp. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */
package com.ibm.watson.developer_cloud.conversation.v1.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.google.gson.annotations.SerializedName;
import com.ibm.watson.developer_cloud.service.model.GenericModel;
import com.ibm.watson.developer_cloud.util.Validator;

/**
 * the createEntity options.
 */
public class CreateEntityOptions extends GenericModel {

  /** The workspace ID. */
  @SerializedName("workspace_id")
  private String workspaceId;
  /** Any metadata related to the value. */
  private Map<String, Object> metadata;
  /** An array of entity values. */
  private List<CreateValue> values;
  /** Whether to use fuzzy matching for the entity. */
  @SerializedName("fuzzy_match")
  private Boolean fuzzyMatch;
  /** The description of the entity. */
  private String description;
  /** The name of the entity. */
  private String entity;

  /**
   * Builder.
   */
  public static class Builder {
    private String workspaceId;
    private Map<String, Object> metadata;
    private List<CreateValue> values;
    private Boolean fuzzyMatch;
    private String description;
    private String entity;

    private Builder(CreateEntityOptions createEntityOptions) {
      workspaceId = createEntityOptions.workspaceId;
      metadata = createEntityOptions.metadata;
      values = createEntityOptions.values;
      fuzzyMatch = createEntityOptions.fuzzyMatch;
      description = createEntityOptions.description;
      entity = createEntityOptions.entity;
    }

    /**
     * Instantiates a new builder.
     */
    public Builder() {
    }

    /**
     * Instantiates a new builder with required properties.
     *
     * @param workspaceId the workspaceId
     * @param entity the entity
     */
    public Builder(String workspaceId, String entity) {
      this.workspaceId = workspaceId;
      this.entity = entity;
    }

    /**
     * Builds a CreateEntityOptions.
     *
     * @return the createEntityOptions
     */
    public CreateEntityOptions build() {
      return new CreateEntityOptions(this);
    }

    /**
     * Adds an value to values.
     *
     * @param value the new value
     * @return the CreateEntityOptions builder
     */
    public Builder addValue(CreateValue value) {
      Validator.notNull(value, "value cannot be null");
      if (this.values == null) {
        this.values = new ArrayList<CreateValue>();
      }
      this.values.add(value);
      return this;
    }

    /**
     * Set the workspaceId.
     *
     * @param workspaceId the workspaceId
     * @return the CreateEntityOptions builder
     */
    public Builder workspaceId(String workspaceId) {
      this.workspaceId = workspaceId;
      return this;
    }

    /**
     * Set the metadata.
     *
     * @param metadata the metadata
     * @return the CreateEntityOptions builder
     */
    public Builder metadata(Map<String, Object> metadata) {
      this.metadata = metadata;
      return this;
    }

    /**
     * Set the values.
     * Existing values will be replaced.
     *
     * @param values the values
     * @return the CreateEntityOptions builder
     */
    public Builder values(List<CreateValue> values) {
      this.values = values;
      return this;
    }

    /**
     * Set the fuzzyMatch.
     *
     * @param fuzzyMatch the fuzzyMatch
     * @return the CreateEntityOptions builder
     */
    public Builder fuzzyMatch(Boolean fuzzyMatch) {
      this.fuzzyMatch = fuzzyMatch;
      return this;
    }

    /**
     * Set the description.
     *
     * @param description the description
     * @return the CreateEntityOptions builder
     */
    public Builder description(String description) {
      this.description = description;
      return this;
    }

    /**
     * Set the entity.
     *
     * @param entity the entity
     * @return the CreateEntityOptions builder
     */
    public Builder entity(String entity) {
      this.entity = entity;
      return this;
    }
  }

  private CreateEntityOptions(Builder builder) {
    Validator.notNull(builder.workspaceId, "workspaceId cannot be null");
    Validator.notNull(builder.entity, "entity cannot be null");
    workspaceId = builder.workspaceId;
    metadata = builder.metadata;
    values = builder.values;
    fuzzyMatch = builder.fuzzyMatch;
    description = builder.description;
    entity = builder.entity;
  }

  /**
   * New builder.
   *
   * @return a CreateEntityOptions builder
   */
  public Builder newBuilder() {
    return new Builder(this);
  }

  /**
   * Gets the workspaceId.
   *
   * @return the workspaceId
   */
  public String workspaceId() {
    return workspaceId;
  }

  /**
   * Gets the metadata.
   *
   * @return the metadata
   */
  public Map<String, Object> metadata() {
    return metadata;
  }

  /**
   * Gets the values.
   *
   * @return the values
   */
  public List<CreateValue> values() {
    return values;
  }

  /**
   * Gets the fuzzyMatch.
   *
   * @return the fuzzyMatch
   */
  public Boolean fuzzyMatch() {
    return fuzzyMatch;
  }

  /**
   * Gets the description.
   *
   * @return the description
   */
  public String description() {
    return description;
  }

  /**
   * Gets the entity.
   *
   * @return the entity
   */
  public String entity() {
    return entity;
  }
}
