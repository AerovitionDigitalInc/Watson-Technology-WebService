# Retrieve and Rank and Solrj

This example shows how to use the [Retrieve and Rank](http://www.ibm.com/watson/developercloud/retrieve-rank.html) service along with the [Solr client in Java (Solrj)](https://wiki.apache.org/solr/Solrj).

## Installation

To run the example you need to install the dependencies

    $ mvn compile
