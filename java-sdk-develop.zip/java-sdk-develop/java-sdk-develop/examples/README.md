# Examples

This examples shows how to use the Java SDK.

## Installation

To run the example you need to install the dependencies

    $ gradle assemble
